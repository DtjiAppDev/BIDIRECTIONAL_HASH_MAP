# Penalty Kick Saver

A Python package contains implementation of a Bidirectional Hash Map.

## Usage

The class BidirectionalHashMap itself can be used to initialise a
bidirectional hash map which is a hash map which has mappings from
keys to values and the other way around. Several methods are in the
class.